# Sprinkle Irrigation Controller
Application of Fuzzy Logic for Sprinkler Controller in Drip Irrigation

## Controling how long a sprinkler should function given the current Temprature and Humidity

**Inputs:**

1. Temprature: In Degree Celsius

2. Humidity: In Percentage(%)

**Output:**

Sprinkler Duration: In Minutes
